import pandas as pd

def summarize_results(csv_path):
    df = pd.read_csv(csv_path)

    # Group by `which`
    grouped = df.groupby("which")

    summary = grouped.agg(
        total_proc_pixels=("proc_pixels", "sum"),
        avg_ms_threshold=("ms_threshold", "mean"),
        p95_ms_threshold=("ms_threshold", lambda x: x.quantile(0.95)),
        frame_count=("frame", "count"),
        total_ms=("ms_threshold", "sum"),
    ).reset_index()

    # Convert ms to seconds
    summary["total_seconds"] = summary["total_ms"] / 1000.0

    # Gpix/s = total pixels / total seconds / 1e9
    summary["gpix_per_sec"] = (
        summary["total_proc_pixels"] / summary["total_seconds"] / 1e9
    )

    # Optional cleanup
    summary = summary.drop(columns=["total_ms"])

    return summary


import sys

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python perfromance.py <path_to_csv>")
        sys.exit(1)

    csv_file = sys.argv[1]
    result = summarize_results(csv_file)
    print(result)

