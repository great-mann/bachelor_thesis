import csv
import math
from pathlib import Path
from statistics import mean, median
from collections import defaultdict

BASE_DIR = Path(__file__).resolve().parent
RESULTS_DIR = BASE_DIR / "results"

# Buckets for spike view
BUCKETS = [0, 1, 2, 4, 8, 16, 33, 66, 100, 200, 500, 1e9]

def pct(ms_sorted, p):
    """Nearest-rank percentile. p in [0, 100]."""
    n = len(ms_sorted)
    if n == 0:
        return float("nan")
    k = math.ceil((p / 100) * n) - 1
    k = max(0, min(k, n - 1))
    return ms_sorted[k]

def load_ms_from_csv(path: Path):
    ms = []
    try:
        with path.open(newline="") as f:
            r = csv.DictReader(f)
            for row in r:
                try:
                    ms.append(float(row["ms_process"]))
                except Exception:
                    pass
    except FileNotFoundError:
        pass
    return ms

def bucket_counts(ms_sorted):
    counts = [0] * (len(BUCKETS) - 1)
    for v in ms_sorted:
        for i in range(len(BUCKETS) - 1):
            if BUCKETS[i] <= v < BUCKETS[i + 1]:
                counts[i] += 1
                break
    return counts

def print_stats(label, ms):
    if not ms:
        print(f"\n== {label} ==")
        print("No valid frames found.")
        return

    ms_sorted = sorted(ms)
    n = len(ms_sorted)

    print(f"\n== {label} ==")
    print(f"Frames: {n}")
    print(f"Mean:   {mean(ms_sorted):.3f} ms")
    print(f"Median: {median(ms_sorted):.3f} ms")
    print(f"p90:    {pct(ms_sorted, 90):.3f} ms")
    print(f"p95:    {pct(ms_sorted, 95):.3f} ms")
    print(f"p99:    {pct(ms_sorted, 99):.3f} ms")
    print(f"Max:    {ms_sorted[-1]:.3f} ms")

    counts = bucket_counts(ms_sorted)
    print("\nBuckets (ms):")
    for i, c in enumerate(counts):
        if c:
            lo, hi = BUCKETS[i], BUCKETS[i + 1]
            print(f"{lo:>6g} .. {hi:>6g}: {c}")

def main():
    if not RESULTS_DIR.exists():
        raise SystemExit(f"Missing results directory: {RESULTS_DIR}")

    # Collect ms values per variant (v1..v6)
    per_variant = defaultdict(list)
    files_found = 0

    # Matches: results/v1/<random>/performance_log.csv, etc.
    for csv_path in RESULTS_DIR.glob("v*/**/performance_log.csv"):
        # Expect variant to be the folder directly under results
        # e.g. results/v3/abc123/performance_log.csv -> variant = "v3"
        try:
            variant = csv_path.relative_to(RESULTS_DIR).parts[0]
        except Exception:
            continue

        files_found += 1
        per_variant[variant].extend(load_ms_from_csv(csv_path))

    if files_found == 0:
        raise SystemExit(f"No performance_log.csv files found under {RESULTS_DIR}")

    # Print per variant, sorted nicely (v1..v6..)
    for variant in sorted(per_variant.keys(), key=lambda s: int(s[1:]) if s[1:].isdigit() else s):
        print_stats(variant, per_variant[variant])

if __name__ == "__main__":
    main()
