import pandas as pd
from pathlib import Path

base_dir = Path(".")
rows = []

for d in sorted(base_dir.iterdir()):
    if not d.is_dir():
        continue

    csv_path = d / "fps.csv"
    if not csv_path.exists():
        continue

    df = pd.read_csv(csv_path)

    if "fps" not in df.columns:
        continue

    fps = df["fps"].dropna()

    rows.append({
        "variant": d.name,
        "mean": fps.mean(),
        "median": fps.median(),
        "min": fps.min(),
        "max": fps.max(),
        "p95": fps.quantile(0.95),
    })

# Build results table
results = pd.DataFrame(rows).set_index("variant")

# Pretty print
print(results.round(3))
