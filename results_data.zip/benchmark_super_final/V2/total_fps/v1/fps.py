import pandas as pd

# Load CSV
df = pd.read_csv("fps.csv")

# Grab fps column
fps = df["fps"].dropna()

stats = {
    "mean": fps.mean(),
    "median": fps.median(),
    "min": fps.min(),
    "max": fps.max(),
    "p95": fps.quantile(0.95),
}

# Print nicely
for k, v in stats.items():
    print(f"{k}: {v:.3f}")
