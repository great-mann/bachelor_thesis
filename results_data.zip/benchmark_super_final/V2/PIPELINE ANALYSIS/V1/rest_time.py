import pandas as pd
import re
import numpy as np

PATH = "perf_log.csv"

# Matches:
# 1) frame number
# 2) threshold mean time (2nd value)
# 3) the rest of the line (message with commas)
LINE_RE = re.compile(r"^\s*(\d+)\s*,\s*([0-9]*\.?[0-9]+)\s*,\s*(.*)\s*$")

REST_RE = re.compile(r"rest time \(ms\):\s*([0-9]*\.?[0-9]+)")
CAND_RE = re.compile(r"candidates Size:\s*(\d+)")

rows = []
with open(PATH, "r", encoding="utf-8", errors="replace") as f:
    for i, line in enumerate(f, start=1):
        line = line.strip()
        if not line:
            continue

        m = LINE_RE.match(line)
        if not m:
            # skip lines that don't match expected structure
            continue

        frame = int(m.group(1))
        threshold_mean_time = float(m.group(2))
        text = m.group(3)

        rest_m = REST_RE.search(text)
        cand_m = CAND_RE.search(text)

        rest_time_ms = float(rest_m.group(1)) if rest_m else np.nan
        candidate_count = int(cand_m.group(1)) if cand_m else np.nan

        rows.append((frame, threshold_mean_time, rest_time_ms, candidate_count))

df = pd.DataFrame(rows, columns=[
    "frame", "threshold_mean_time_ms", "rest_time_ms", "candidate_count"
])

# Drop rows we couldn't parse
df = df.dropna(subset=["threshold_mean_time_ms", "rest_time_ms", "candidate_count"])

# Candidate count ranges (edit bins if you want different groupings)
bins = [0, 1, 2, 5, 10, 20, np.inf]
labels = ["0-1", "2", "3-5", "6-10", "11-20", "20+"]

df["candidate_range"] = pd.cut(
    df["candidate_count"],
    bins=bins,
    labels=labels,
    include_lowest=True
)

def p95(x: pd.Series) -> float:
    x = x.dropna().to_numpy()
    return float(np.percentile(x, 95)) if x.size else np.nan

summary = (
    df.groupby("candidate_range", observed=True)
      .agg(
          samples=("rest_time_ms", "count"),
          mean_rest_time_ms=("rest_time_ms", "mean"),
          p95_rest_time_ms=("rest_time_ms", p95),
          mean_threshold_time_ms=("threshold_mean_time_ms", "mean"),
      )
      .reset_index()
)

pd.set_option("display.float_format", "{:.3f}".format)
print(summary)
