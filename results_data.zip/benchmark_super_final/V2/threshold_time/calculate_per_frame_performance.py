import csv
import glob
import os
from collections import defaultdict

# ---- config ----
DIR = "."
PATTERN = "threshold_times*.csv"   # grabs threshold_times.csv, threshold_times_v1.csv, etc.

def percentile(sorted_vals, pct):
    """pct in [0,1]. Simple index-based percentile."""
    if not sorted_vals:
        return None
    n = len(sorted_vals)
    idx = int(pct * (n - 1))
    return sorted_vals[idx]

# ---- load ----
ms_by_variant = defaultdict(list)
pix_by_variant = defaultdict(list)
bad_rows = 0
files_read = 0

for path in glob.glob(os.path.join(DIR, PATTERN)):
    files_read += 1
    with open(path, newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row or len(row) < 3:
                bad_rows += 1
                continue
            try:
                variant = row[0].strip()
                proc_pixels = int(row[1])
                ms = float(row[2])
            except (ValueError, TypeError):
                bad_rows += 1
                continue

            ms_by_variant[variant].append(ms)
            pix_by_variant[variant].append(proc_pixels)

# ---- compute + print ----
variants = sorted(ms_by_variant.keys())  # will include v1..v6 if present

headers = ["variant", "frames", "avg_ms", "p50", "p90", "p95", "p99", "min", "max", "avg_pix"]
print(" | ".join(h.rjust(8) for h in headers))
print("-" * (len(headers) * 11))

for v in variants:
    vals = ms_by_variant[v]
    vals.sort()
    n = len(vals)

    avg_ms = sum(vals) / n
    p50 = percentile(vals, 0.50)
    p90 = percentile(vals, 0.90)
    p95 = percentile(vals, 0.95)
    p99 = percentile(vals, 0.99)

    min_ms = vals[0]
    max_ms = vals[-1]

    pix = pix_by_variant[v]
    avg_pix = sum(pix) / len(pix) if pix else 0

    print(
        f"{v:>8} | "
        f"{n:>8} | "
        f"{avg_ms:>8.3f} | "
        f"{p50:>8.3f} | "
        f"{p90:>8.3f} | "
        f"{p95:>8.3f} | "
        f"{p99:>8.3f} | "
        f"{min_ms:>8.3f} | "
        f"{max_ms:>8.3f} | "
        f"{avg_pix:>8.0f}"
    )

print(f"\nFiles read: {files_read}, bad/ignored rows: {bad_rows}")
